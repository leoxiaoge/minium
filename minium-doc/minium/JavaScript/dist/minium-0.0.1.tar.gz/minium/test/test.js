const Minium = require("../")
// console.log("Minium", Minium)
function sleep(timeout) {
    return new Promise((resolve, reject) => {
        setTimeout(resolve, timeout);
    });
}

async function main() {
    try {
        const client = await Minium.create(undefined, undefined, process.argv[2], undefined, "debug")
        let app = await client.getApp()
        let page = await app.getCurrentPage()
        let element = await page.getElement("#view")
        console.log("view tag name", await element.tag_name)
        console.log("view wxml", await element.wxml())        
        await client.shutdown()
    } catch (e) {
        console.log(e)
    }
    process.exit(0)
}

main()





